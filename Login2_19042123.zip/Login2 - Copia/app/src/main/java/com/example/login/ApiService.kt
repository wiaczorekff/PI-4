package com.example.login

import retrofit2.http.GET

interface ApiService {

        @GET("/")
        fun getProdutos(): retrofit2.Call<List<Produtos>>

    }